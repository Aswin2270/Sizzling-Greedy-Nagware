user_input = "random"
def show_menu():
  print("menu:")
  print("1. add an item:")
  print("2. mark as done:")
  print("3. view items:")
  print("4. exit:")
  while user_input !="4":
  show_menu()
  user_input = input("enter your choice: ")
  if user_input =="1":
    print ("add an item")
  elif user_input =="2":
    print ("mark as done")
  elif user_input =="3":
    print ("view the item")
  elif user_input =="4":
    print ("bye")
  else:
    print("please enter one of 1,2,3, or 4") 
 